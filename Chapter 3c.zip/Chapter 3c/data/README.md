# Data, figures and videos used in the scripts

Most of the images and videos come from the OpenCV samples data directory (opencv/samples/data/).

The rest have been downloaded from the following pages:

  * [images](https://github.com/abidrahmank/OpenCV2-Python-Tutorials)
  * [videos](http://www.engr.colostate.edu/me/facil/dynamics/avis.htm)


  