# Path Finding with Edaqa Mortoray

This repository contains the source code that is required for the [Path Finding]() classes.


## Setup

Ensure you are using a recent version of Python, 3.6.1 or higher.

Install PyGame, which is used to create graphics.

`python3 -m pip install -U pygame`

