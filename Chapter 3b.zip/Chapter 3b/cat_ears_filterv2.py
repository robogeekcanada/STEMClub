import numpy as np
import cv2

cam = cv2.VideoCapture(0)
font = cv2.FONT_HERSHEY_SIMPLEX

GREEN = (0,255,0)

face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
cat_img = cv2.imread('cat_ears2.png')

tup = cat_img.shape
height = tup[0]
width = tup[1]


while (cam.isOpened()):

    ret, frame = cam.read()

    if ret:

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)


        # Detect faces in the image
        faces = face_cascade.detectMultiScale(gray,scaleFactor=1.1,minNeighbors=5,
                                             minSize=(30, 30))

        # Draw a rectangle around the faces
        for (x, y, w, h) in faces:
            #cv2.rectangle(frame, (x, y), (x+w, y+h), GREEN, 2)

            #Capture a bigger region x,y,w,h
            x -= 5
            y -= 15
            w +=10
            h +=5

            fx = (w/width)
            fy =(h/height)

            #Capture face
            face_img = frame[y:y+h, x:x+w]

            #Resize cat picture with respect to size of face
            cat_img_resized = cv2.resize(cat_img,None,
                                         fx = fx, fy = fy , interpolation = cv2.INTER_CUBIC)
            
        
            #We need to remove black of picture to create transparency
            #We do this by making a mask_inv (basically turning color into black
            #and black pixels to white
            img2gray = cv2.cvtColor(cat_img_resized, cv2.COLOR_BGR2GRAY)
            ret, mask = cv2.threshold(img2gray, 10, 255, cv2.THRESH_BINARY)
            mask_inv = cv2.bitwise_not(mask)
            #cv2.imshow('mask_inv', mask_inv)

            #Now replace the area of cat face in face image with
            #black pixels using mask_inv
            img1_bg = cv2.bitwise_and(face_img, face_img,mask = mask_inv)
            #cv2.imshow('img1_bg',img1_bg)
    
            #Replace black pixels with color pixels from cat face using mask
            img2_fg = cv2.bitwise_and(cat_img_resized,cat_img_resized,mask = mask)
            cv2.imshow('img2_fg',img2_fg)

            #Add the img1_bg + img2_fg
            dst = cv2.add(img1_bg,img2_fg)

            frame[y:y+h, x:x+w] = dst
            
            #cv2.imshow('cat_resized', cat_img_resized)


        cv2.imshow("Faces found", frame)


        if cv2.waitKey(1) == 27:
            break

cam.release()
cv2.destroyAllWindows()
