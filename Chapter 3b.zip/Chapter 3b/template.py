#This file is a template for OpenCV programs

import cv2
import numpy as np

BLUE = (255,0,0)
GREEN = (0,255,0)
RED = (0,0,255)

img = np.zeros((512,512,3), np.uint8)

#Display image
cv2.imshow('Window name',img)
cv2.waitKey(0)
cv2.destroyAllWindows()
