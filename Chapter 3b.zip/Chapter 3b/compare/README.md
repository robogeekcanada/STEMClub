python-compare-two-images
=========================

Comparing two pictures
