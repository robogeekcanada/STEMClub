import numpy as np
import cv2

cam = cv2.VideoCapture(0)
font = cv2.FONT_HERSHEY_SIMPLEX

cam.set(3,480)
cam.set(4,320)

face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
eye_cascade = cv2.CascadeClassifier('haarcascade_eye.xml')

#img = cv2.imread('OSZ somewhere.jpg')

while (cam.isOpened()):

    ret, frame = cam.read()

    if ret:

        frame =cv2.flip(frame,1)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)


        # Detect faces in the image
        faces = face_cascade.detectMultiScale(gray,scaleFactor=1.1,minNeighbors=5,
                                             minSize=(30, 30)) #flags = cv2.CV_HAAR_SCALE_IMAGE)


        # Draw a rectangle around the faces
        for (x, y, w, h) in faces:
            cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

            
            cv2.circle(frame,(x+int(w/2),y+int(w/2)),int(w/2),(0,0,255),3)

            xoffset = int(w*0.75)
            yoffset = int(h*0.25)

            #draw mouth
            cv2.rectangle(frame,(x+int(w/4),y+ int(yoffset+w/3)),(x+xoffset,y+int(yoffset*2+w/3)),(0,0,255),3)

            #draw left eye
            cv2.rectangle(frame,(x+int(w/5),y+yoffset),(x+int(w/2),y+int(yoffset*2)),(0,0,255),3)

            eye_size = 50

            #draw right eye
            cv2.rectangle(frame,(x+int(w/2+10),y+yoffset),(x+int(w/2+45),y+yoffset*2),(0,0,255),3)



            roi_gray = gray[y:y+h, x:x+w]
            roi_color = frame[y:y+h, x:x+w]

            
##            eyes = eye_cascade.detectMultiScale(roi_gray)
##
##            for (ex,ey,ew,eh) in eyes:
##                cv2.rectangle(roi_color,(ex,ey),(ex+ew,ey+eh),(0,255,0),2)
##                cv2.circle(frame,(ex,ey),(ew/2),(0,0,255),3)


        cv2.namedWindow('Faces found')
        cv2.imshow("Faces found", frame)

        if cv2.waitKey(1)> 10:

            videoLoop = False
            cv2.destroyWindow('Faces found')
            break


cam.release()
cv2.destroyAllWindows()
