#Demo Harris corner detection

import cv2
import numpy as np

RED = (0,0,255)

img = cv2.imread('home.jpg')


gray= cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

sift = cv2.SIFT()
kp = sift.detect(gray,None)

img= cv2.drawKeypoints(gray,kp)

cv2.imshow('SIFT',img)

if cv2.waitKey(0) & 0xff == 27:
    cv2.destroyAllWindows()

