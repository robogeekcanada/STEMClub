#this program uses the drawing functions with camera recording real time

import cv2
import numpy as np

cam = cv2.VideoCapture(0)
#cam.set(3,1024)
#cam.set(4,768)

while (cam.isOpened()):

    ret, frame = cam.read()
    frame = cv2.flip(frame,1)

    if ret:

        cv2.line(frame,(0,199),(199,0),(0,0,255),2)

        cv2.rectangle(frame,(384,0),(510,128),(0,255,0),3)

        cv2.circle(frame,(4,63),63,(0,0,255),-1)

        cv2.ellipse(frame,(256,256),(100,50),0,0,180,255,-1)

        pts = np.array([[10,5],[20,30],[70,20],[50,10]], np.int32)
        pts = pts.reshape (-1,1,2)
        cv2.polylines(frame,[pts],True,(0,255,255))

        font = cv2.FONT_HERSHEY_SIMPLEX
        cv2.putText(frame,'OpenCV',(10,500),font, 4,(255,255,255))


        cv2.imshow('frame', frame)

        if cv2.waitKey(1) == 27:
            break

cam.release()
cv2.destroyAllWindows()
