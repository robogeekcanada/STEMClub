import cv2
import numpy as np
from animation_support import *
from support.reeds_shepp_path_planning import *
    
def main():

    start_x = 40
    start_y = 130
    start_yaw = np.deg2rad(90.0)

    end_x = 320
    end_y = 275
    end_yaw = np.deg2rad(115.0)

    curvature = 0.05
    step_size = 0.5

    px, py, pyaw, mode, clen = reeds_shepp_path_planning(start_x, start_y, start_yaw,
                                                         end_x, end_y, end_yaw,
                                                         curvature, step_size)

    #Display car animation
    for x,y,yaw in zip(px, py, pyaw):
        parking_img = cv2.imread("images\parking_lot.jpg")
        img = set_car_position(parking_img, int(x), int(y), int(np.rad2deg(yaw)))
        cv2.imshow('Parking Lot', img)
        cv2.waitKey(15)

    #Display trail using red circles
    for x,y in zip(px,py):
        if int(x) > 0:
            cv2.circle(img,(int(x)+52, int(y)),2,RED,-1)
        else:
            cv2.circle(img,(int(x), int(y)),2,RED,-1)
        cv2.imshow('Parking Lot', img)

if __name__ == '__main__':
    main()



    
    




