import cv2
from animation_support import *

def set_obstacles():
    ox, oy = [], []

    #Outside Boundary
    for i in range(500):
        ox.append(i)
        oy.append(0.0)
    for i in range(500):
        ox.append(500.0)
        oy.append(i)
    for i in range(501):
        ox.append(i)
        oy.append(500.0)
    for i in range(500):
        ox.append(0.0)
        oy.append(i)

    #Obstacles...
    for i in range(200):
        ox.append(22.0)
        oy.append(i)
    for i in range(22,240,1):
        ox.append(i)
        oy.append(200)
    for i in range(22,310,1):
        ox.append(i)
        oy.append(280)

    return ox, oy


def draw_obstacles(background, ox, oy):

    for x,y in zip(ox,oy):
        if int(x) > 0:
            cv2.circle(background, ((int(x)+52) ,(int(y)) ), 5, BLUE, -1)
        else:
            cv2.circle(background, ((int(x)) ,(int(y)) ), 5, BLUE, -1)

    cv2.line(background, (0,0),(52,0), BLUE, 10)
    cv2.line(background, (0,500),(52,500), BLUE, 10)

    return background
