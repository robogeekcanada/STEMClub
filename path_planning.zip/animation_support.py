import cv2
import numpy as np

WHITE = (255,255,255)
BLUE = (255,0,0)
RED = (0,0,255)


def rotate_car(img, center, angle, rotation_scale, output_scale):
    
    rotation_matrix = cv2.getRotationMatrix2D(center, angle, rotation_scale)
    img_rotated = cv2.warpAffine(img, rotation_matrix, output_scale)
    return img_rotated

def mask_and_crop(img, background, x, y, size):

    black= np.array([0, 0, 0])
    mask = cv2.inRange(img, black, black)

    masked_image = np.copy(img)
    masked_image[mask !=0] = [0,0,0]
   
    cropped_image = background[y:y+size[0], x:x+size[1]]
    cropped_image[mask == 0] = [0, 0, 0]

    output_image = cropped_image + masked_image
    return output_image


def set_car_position(background, x,y,direction):

    red_car = cv2.imread("images/red_car.png")
    h,w = red_car.shape[:2]
    center = (int(w/2), int(h/2))
    rotation_scale = 1.0
    output_scale = (int(w*1.0),int(h*1.0))
    angle  = 0
    
    rotated_car = rotate_car(red_car, center, direction*-1,
                             rotation_scale, output_scale)
    
    size = rotated_car.shape
    b2 = background.copy()    

    translated_car = mask_and_crop(rotated_car, b2, x, y, size)
    background[y:y+size[0], x:x+size[1]] = translated_car

    return background

def main():

    sx = 10.0
    sy = 10.0
    syaw = 90.0
    gx = 320.0
    gy = 275.0
    gyaw = 115.0

    parking_img = cv2.imread("images/parking_lot.jpg")
    img = set_car_position(parking_img, int(sx), int(sy), int(syaw))
    cv2.imshow('Parking Lot', img)
    cv2.waitKey(500)

    parking_img = cv2.imread("images/parking_lot.jpg")
    img = set_car_position(parking_img, int(gx), int(gy), int(gyaw))
    cv2.imshow('Parking Lot', img)
    cv2.waitKey(500)
    

if __name__ == '__main__':
    main()
