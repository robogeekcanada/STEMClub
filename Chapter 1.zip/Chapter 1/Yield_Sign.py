import numpy as np
import cv2


yield_sign_cascade = cv2.CascadeClassifier('yieldsign12Stages.xml')

camera = cv2.VideoCapture(0)
#camera = cv2.VideoCapture(0) 

while True:

    ret, frame = camera.read()
    
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)


    ysigns = yield_sign_cascade.detectMultiScale(gray, 1.4, 1)
    
    for (x,y,w,h) in ysigns:
    
        cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,0),2)
        


    cv2.imshow("yield signs detected", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

camera.release()
cv2.destroyAllWindows()
