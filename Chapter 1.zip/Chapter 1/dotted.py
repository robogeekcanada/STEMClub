import numpy as np
import cv2
import math

camera = cv2.VideoCapture(0)

GREEN = (0,255,0)


def linedot(img, coord1, coord2, COLOR, thickness, partisions = 20):

    x1 = coord1[0]
    y1 = coord1[1]

    x2 = coord2[0]
    y2 = coord2[1]

    width = x2 - x1
    height = y2 - y1

    x_incr  = int(width/partisions)
    y_incr  = int(height/partisions)

    iterations = int(partisions/2)

    for i in range (iterations):

        cv2.line(img, (x1, y1), (x1 + x_incr, y1 + y_incr), COLOR, thickness)

        x1 = x1 + 2*x_incr
        y1 = y1 + 2*y_incr


def circledot(img, coord1, radius, COLOR, thickness, partisions = 20):

    x1 = coord1[0]
    y1 = coord1[1]

    incr = int(partisions/2)

    for i in range (0, 360, partisions):

        theta = math.radians(i)
        theta_incr = math.radians(i+incr)
        
        xr1 = int(x1 + radius*math.cos(theta))
        yr1 = int(y1 + radius*math.sin(theta))

        xr2 = int(x1 + radius*math.cos(theta_incr))
        yr2 = int(y1 + radius*math.sin(theta_incr))
       
        cv2.line(img, (xr1, yr1), (xr2, yr2), COLOR, thickness)


while True:

    ret, frame = camera.read()
    
    linedot(frame, (0,0),(100,100), GREEN, 1)
    circledot(frame, (200,200), 50, GREEN, 1 , 20)

    cv2.imshow("dotted", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

camera.release()
cv2.destroyAllWindows()
