import numpy as np
import cv2
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import glob

#All cascades for detecting traffic features
traffic_lights_cascade = cv2.CascadeClassifier('TrafficLight_HAAR_16Stages.xml')
stop_sign_cascade = cv2.CascadeClassifier('Stopsign_HAAR_19Stages.xml')
yield_sign_cascade = cv2.CascadeClassifier('yieldsign12Stages.xml')
speed_limit_signs_cascade = cv2.CascadeClassifier('Speedlimit_24_15Stages.xml')
cars_cascade = cv2.CascadeClassifier('cars.xml')

camera = cv2.VideoCapture("vegas_Trim.mp4")

font = cv2.FONT_HERSHEY_SIMPLEX
fontSize = 0.6
fontThickness = 2

#traffic light detection
def detect_traffic_lights(image):

        #Create region of interest to see at top half of screen
        height = image.shape[0]
        width = image.shape[1]
        
        roi = image[0:int(height/2), 0:width]

        #Greyscale image
        grey = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)

        #Get all traffic lights within region of interest
        tlights = traffic_lights_cascade.detectMultiScale(grey, 1.3, 1)

        #FOr each traffic light position and size, make a rectangle
        for (x,y,w,h) in tlights:

                cv2.rectangle(image,(x,y),(x+w,y+h),(0,255,0),2)
                #cv2.putText(image, "traffic light", (int(x+w), int(y)), font, fontSize,([0,0,255]),fontThickness)
                label(int(x+w), y, "Traffic Light", image)
                cv2.circle(image,(int(x + 0.5*w), int(y + h*0.3)), int(w/6),(0,0,255),-1)
                cv2.circle(image,(int(x + 0.5*w), int(y + h*0.6)), int (w/6),(0,255,255),-1)
                cv2.circle(image,(int(x + 0.5*w), int(y + h*0.9)), int(w/6),(0,255,0),-1)


#stop sign detection
def stop_sign_detection(image):
        
        #Greyscale image
        grey = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        #Get all stop signs within image
        ssigns = stop_sign_cascade.detectMultiScale(grey, 1.3, 5)

        #For every stop sign position and size, draw a rectangle around it
        for (x,y,w,h) in ssigns:

                cv2.rectangle(image,(x,y),(x+w,y+h),(0,0,255),2)
                label(int(x+w), y, "Stop Sign", image)

def speed_limit_detection(image):
        
        grey = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        slsigns = speed_limit_signs_cascade.detectMultiScale(grey, 1.4, 1)
    
        for (x,y,w,h) in slsigns:
    
                cv2.rectangle(image,(x,y),(x+w,y+h),(0,255,0),2)
                label(int(x+w), y, "Speed Limit", image)

def yield_sign_detection(image):

        #Greyscale image
        grey = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        ysigns = yield_sign_cascade.detectMultiScale(grey, 1.4, 1)
    
        for (x,y,w,h) in ysigns:
    
                cv2.rectangle(image,(x,y),(x+w,y+h),(0,255,0),2)
                label(int(x+w), y, "Yield", image)

def car_detection(image):

        #Greyscale image
        grey = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        cars = cars_cascade.detectMultiScale(grey, 1.3, 3)
    
        for (x,y,w,h) in cars:
    
                cv2.rectangle(image,(x,y),(x+w,y+h),(0,255,0),2)
                label(int(x+w), y, "Car", image)

        

#Labelling function
def label(x, y, message, image):
        cv2.rectangle(image, (x,y-20), (x+int(len(message)*10),y), (0,255,0), -1)
        cv2.putText(image, message, (x, y-8), font, fontSize, ([255,255,255]), fontThickness)


def main():

        while (camera.isOpened()):

                ret, frame = camera.read()

                frame = cv2.resize(frame, None, fx = 0.5, fy = 0.5)

                if ret == True:

                        #Detect tlights
                        detect_traffic_lights(frame)

                        #Detect stop signs
                        stop_sign_detection(frame)

                        #Detect speed limit signs
                        speed_limit_detection(frame)

                        #Detect yield signs
                        yield_sign_detection(frame)

                        #Detect cars
                        car_detection(frame)

                        cv2.imshow("traffic lights detected", frame)

                        if cv2.waitKey(1) & 0xFF == ord('q'):
                                break

                else:
                        break

        camera.release()
        cv2.destroyAllWindows()

main()
