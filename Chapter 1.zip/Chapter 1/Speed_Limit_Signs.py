import numpy as np
import cv2


speed_limit_signs_cascade = cv2.CascadeClassifier('Speedlimit_24_15Stages.xml')

camera = cv2.VideoCapture(0)
#camera = cv2.VideoCapture(0) 

while True:

    ret, frame = camera.read()
    
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)


    slsigns = speed_limit_signs_cascade.detectMultiScale(gray, 1.4, 1)
    
    for (x,y,w,h) in slsigns:
    
        cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,0),2)
        


    cv2.imshow("speed limit signs detected", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

camera.release()
cv2.destroyAllWindows()
