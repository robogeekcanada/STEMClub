import pygame
import time
import random
from support_lib import *
#import Space_invaders10 as SpInv

pygame.init()

def gameScreen(x1,y1):
    gameDisplay.blit(gameScreenImg,(x1,y1))




#logic for the crash screen
def text_objects(text, font):
    textSurface = font.render(text, True, Red)
    return textSurface, textSurface.get_rect()

def text_objects2(text, font):
    textSurface = font.render(text, True, yellow)
    return textSurface, textSurface.get_rect()

def text_objects3(text, font):
    textSurface = font.render(text, True, Black)
    return textSurface, textSurface.get_rect()


def button(msg,x,y,w,h,ic,ac,action=None):
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    #play button
    #checking if the mouse is over the botton
    if x+w > mouse[0] > x and y+h > mouse[1] > y:
        pygame.draw.rect(gameDisplay, ac, (x,y,w,h))
        if click[0] == 1 and action != None:
            if action == "Play":
                return "Play"

                #game_loop()
            elif action == "Quit":
                pygame.quit()
                quit()
            elif action == "unpause":
                unpause()
            elif action == "Play again":
                pygame.mixer.music.unpause()
                game_loop()
            elif action == "options":
                options()
            elif action == "Sounds":
                Sounds()
            elif action == "menu":
                game_intro()
    else:
        pygame.draw.rect(gameDisplay, ic, (x,y,w,h))

    smallText = pygame.font.Font("freesansbold.ttf",20)
    textSurf, textRect = text_objects3(msg, smallText)
    textRect.center = ( (x + (w/2)), (y + (h/2)) )
    gameDisplay.blit(textSurf, textRect)

def paused():

    pygame.mixer.music.pause()

    while pause:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

        gameDisplay.fill(Black)
        largeText = pygame.font.Font('freesansbold.ttf',100)
        TextSurf, TextRect = text_objects2("Paused", largeText)
        TextRect.center = ((display_width/2),(display_height/7))
        gameDisplay.blit(TextSurf, TextRect)
        
        button("MENU",300,500,200,40,Grey,Light_Grey,"menu")

        button("RETURN",300,400,200,40,Grey,Light_Grey,"unpause")
        button("QUIT",300,450,200,40,Grey,Light_Grey,"Quit")

        pygame.display.update()
        clock.tick(15)



def game_intro():

    #pygame.mixer.music.play(-1)

    intro = True

    while intro:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

        gameDisplay.fill(Black)
        largeText = pygame.font.Font('freesansbold.ttf',100)
        TextSurf, TextRect = text_objects2("STAR WARS", largeText)
        TextRect.center = ((display_width/2),(display_height/7))
        gameDisplay.blit(TextSurf, TextRect)

        answer = button("PLAY",300,400,200,40,Grey,Light_Grey,"Play")

        if answer == "Play":
            print("Play")
            return True

        
        button("QUIT",300,450,200,40,Grey,Light_Grey,"Quit")
        button("OPTIONS",300,500,200,40,Grey,Light_Grey,"options")

        DeathStarImg = pygame.image.load(r"Death_Star_Alpha.png")
        def Death_Star(x4,y4):
            gameDisplay.blit(DeathStarImg,(x4,y4))
        
        Death_Star(x4,y4)
        pygame.display.update()
        clock.tick(15)
