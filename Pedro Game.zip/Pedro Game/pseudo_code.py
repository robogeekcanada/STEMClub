#Game intro

def game_intro():

    option = 1

    return option

def game_loop():

    answer = game_intro()

    print(answer)

def main():

    game_loop()


main()
