import pygame
import time
import random
from support_lib import *
from game_intro import *

#things to do
'''give the player and enemies a weapon, put in multiple enemies, add levels, increase the games difficulty every level,
give different characcter options, make main menu and options, give the game sound effects, put different enemies in different levels,
add bonus ships(star destroyers)and make the drop power ups, make different power ups, eventually mak cutscenes and make a story,
turn into an exacatable UPLOAD TO APP STORE WHEN FINISHED '''

#pygame.init()

game_intro()




def gameScreen(x1,y1):
    gameDisplay.blit(gameScreenImg,(x1,y1))


#drawing the bullet
def bullet(x3,y3):
    gameDisplay.blit(bullet1,(x3,y3))

#drawing the Ty-fighter
def TY_Fighter(x2,y2):
    gameDisplay.blit(TYFighterImg,(x2,y2))

#drawing the xWing
def Xwing(x,y):
    gameDisplay.blit(XwingImg,(x,y))



def message_display(text):
    largeText = pygame.font.Font('freesansbold.ttf',115)
    TextSurf, TextRect = text_objects(text, largeText)
    TextRect.center = ((display_width/2),(display_height/2))
    gameDisplay.blit(TextSurf, TextRect)

    pygame.display.flip()

    time.sleep(2)

    game_loop()

def Sounds():

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        
        gameDisplay.fill(Black)
        largeText = pygame.font.Font('freesansbold.ttf',100)
        TextSurf, TextRect = text_objects2("Sounds", largeText)
        TextRect.center = ((display_width/2),(display_height/7))
        gameDisplay.blit(TextSurf, TextRect)

        pygame.draw.rect(gameDisplay,(Grey),(300,200,200,40))
        pygame.draw.rect(gameDisplay,(Grey),(300,350,200,40))

        SmallText = pygame.font.Font('freesansbold.ttf',20)
        TextSurf, TextRect = text_objects3("MUSIC", SmallText)
        TextRect.center = ( (display_width/2),(220) )
        gameDisplay.blit(TextSurf, TextRect)

        SmallText = pygame.font.Font('freesansbold.ttf',20)
        TextSurf, TextRect = text_objects3("SOUND EFFECTS", SmallText)
        TextRect.center = ( (display_width/2),(370) )
        gameDisplay.blit(TextSurf, TextRect)
        
        button("ON",300,250,90,40,Green,Light_Green,"on1")
        button("OFF",410,250,90,40,Red,Light_Red,"off1")
        button("ON",300,400,90,40,Green,Light_Green,"on2")
        button("OFF",410,400,90,40,Red,Light_Red,"off2")

        pygame.display.update()
        clock.tick(15)

def options():

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        
        gameDisplay.fill(Black)
        largeText = pygame.font.Font('freesansbold.ttf',100)
        TextSurf, TextRect = text_objects2("Options", largeText)
        TextRect.center = ((display_width/2),(display_height/7))
        gameDisplay.blit(TextSurf, TextRect)

        button("SOUNDS",300,200,200,40,Grey,Light_Grey,"Sounds")

        pygame.display.update()
        clock.tick(15)

def crash():

    pygame.mixer.music.pause()
    pygame.mixer.Sound.play(crash_sound)

    largeText = pygame.font.Font('freesansbold.ttf',100)
    TextSurf, TextRect = text_objects("GAME OVER", largeText)
    TextRect.center = ((display_width/2),(display_height/2))
    gameDisplay.blit(TextSurf, TextRect)
    

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        
        button("PLAY AGAIN",100,450,200,40,Grey,Light_Grey,"Play again")
        button("QUIT",550,450,200,40,Grey,Light_Grey,"Quit")

        pygame.display.update()
        clock.tick(15)


def hit():

    pygame.mixer.Sound.play(crash_sound)



def unpause():
    global pause
    pygame.mixer.music.unpause()
    pause = False


        
#game loop
def game_loop():
    global pause

    x_change = 0
    x3_change = 0
    y3_change = 0

    x = (display_width * 0.43)
    y = (display_height * 0.8)


    x3 = (x + (xwing_width/2))
    y3 = y

    bulletW = 3

    x2 = 0
    y2 =  1
    tyf_speed = 2

    gameExit = False

    while not gameExit:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_a:
                    x_change = -5
                    x3_change = x_change
                if event.key == pygame.K_d:
                    x_change = 5
                    x3_change = x_change
                if event.key == pygame.K_p:
                    pause = True
                    paused()
                if event.key == pygame.K_SPACE:
                    y3_change = -8
                    x3_change = 0
                    pygame.mixer.Sound.play(blaster_sound)

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_a or event.key == pygame.K_d or event.key  == pygame.K_SPACE:
                    x_change = 0
                    x3_change = 0

        mouse = pygame.mouse.get_pos()

        x += x_change
        x3 += x3_change
        y3 += y3_change

        gameScreen(x1,y1)
        bullet(x3,y3)
        Xwing(x,y)
        TY_Fighter(x2,y2)
        x2 += tyf_speed

        #making the invader/ty fighter move down and to the sides
        if x2 + tyf_width > 800 or x2 < 0:
            y2 += 40
            tyf_speed *= -1

        #checking if the player has hit the set bondries
        if x > display_width - xwing_width or x < 0 or y > display_height - xwing_height or y < 300:
            crash()

        #checking if player has crashed into an invader
        if y < y2 + tyf_height:
            print('y crossover')

            if x > x2 and x < x2 + tyf_width or x + xwing_width > x2 and x + xwing_width < x2 + tyf_width:
                print ('x crossover')
                crash()

        #checking if the bullet hit the invader
        if y3 < y2 + tyf_height:
            if x3 > x2 and x3 < x2 + tyf_width or x3 + bulletW > x2 and x3 + bulletW < x2 + tyf_width:
                hit()
                
        

        pygame.display.flip()
        clock.tick(60)


game_loop()
pygame.quit()
