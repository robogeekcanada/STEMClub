import pygame
import time
import random

pygame.init()

pygame.display.set_caption( '--===STAR WARS===---')
clock = pygame.time.Clock()

#loading Sounds
crash_sound = pygame.mixer.Sound(r"retro_explosion.wav")
GameOver_sound = pygame.mixer.Sound(r"retro_death.wav")
blaster_sound = pygame.mixer.Sound(r"blaster_shot.wav")

#load music
pygame.mixer.music.load(r"Star_Wars_Theme.mp3")

''' if u would like to change the screens size
change display width and height to adjust it to your screen'''
display_width = 800
display_height = 600

gameDisplay = pygame.display.set_mode((display_width,display_height))

x1 = (display_width * 0)
y1 = (display_height * 0)

x4 = 280
y4 = 150


#players
#Xwing = "C:\Users\pedro\OneDrive\Desktop\Space_invaders\xwing_alpha_version2.png"
#melenium falcon = ""

#defining colours with RGB
Black = (0,0,0)
White = (255,255,255)
Red = (191,0,0)
Light_Red = (255,0,0)
Blue = (0,0,255)
Green = (0,191,0)
Light_Green = (0,255,0)
yellow = (255,250,0)
Light_Grey = (192,192,192)
Grey = (128,128,128)
Navy = (0,0,128)

xwing_width = 128
xwing_height = 90

tyf_height = 84
tyf_width = 64

pause = False
#crash = True
options = True

#making the stars in the background
gameScreenImg = pygame.image.load(r'background_v3.jpg')
#loading the player/Xwing
XwingImg = pygame.image.load(r'xwing_alpha_version2.png')
#loading the invader/TY-Fighter
TYFighterImg = pygame.image.load(r'TY-Fighter_Alpha.png')
#Red bullet
bullet1 = pygame.image.load(r'bullet.png')
