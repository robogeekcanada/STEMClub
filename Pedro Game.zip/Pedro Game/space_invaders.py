import pygame

pygame.init()
''' if u would like to change the screens size
change display width and height to adjust it to your screen'''
display_width = 800
display_height = 600

#defining colours with RGB
Black = (0,0,0)
White = (255,255,255)
Grey = (127,127,127)
Maroon = (136,0,21)
Blue = (0,86,172)
Dark_Grey = (72,72,72)
light_Grey = (195,195,195)

gameDisplay = pygame.display.set_mode((display_width,display_height))
pygame.display.set_caption( '--===STAR WARS===--')
clock = pygame.time.Clock()

XwingImg = pygame.image.load('xwing_alpha_version2.png')

def Xwing(x,y):
    gameDisplay.blit(XwingImg,(x,y))

x = (display_width * 0.45)
y = (display_height * 0.8)

crashed = False

while not crashed:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            crashed = True

    
    Xwing(x,y)
    pygame.display.flip()
    clock.tick(60)

pygaame.quit()
