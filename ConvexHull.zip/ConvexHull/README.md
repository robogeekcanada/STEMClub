**Usage:**

**Python**

`python3 example.py <image_path>`

It takes sample.jpg (default) - if no argument provided.

**C++**

```g++ example.cpp `pkg-config opencv --cflags --libs` -o example```

OR directly run the program using `./example <image_path>`
