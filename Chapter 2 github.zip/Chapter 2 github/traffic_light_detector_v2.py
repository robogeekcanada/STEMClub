import numpy as np
import cv2
from hsv_values import *

GREEN = (0,255,0)
ORANGE = (0,128,255)


def filter_color(img, color):
    image = np.copy(img)

    # Convert BGR to HSV
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

    if (color == 'red'):

        Hue_l = hue_red_l
        Hue_h = hue_red_h
        Saturation_l = saturation_red_l
        Saturation_h = saturation_red_h
        Lightness_l = lightness_red_l
        Lightness_h = lightness_red_h

    if (color == 'yellow'):
        Hue_l = hue_yellow_l
        Hue_h = hue_yellow_h
        Saturation_l = saturation_yellow_l
        Saturation_h = saturation_yellow_h
        Lightness_l = lightness_yellow_l
        Lightness_h = lightness_yellow_h

    if (color == 'green'):
        Hue_l = hue_green_l
        Hue_h = hue_green_h
        Saturation_l = saturation_green_l
        Saturation_h = saturation_green_h
        Lightness_l = lightness_green_l
        Lightness_h = lightness_green_h
            

    # define range of color in HSV
    lower = np.array([Hue_l, Saturation_l, Lightness_l])
    upper  = np.array([Hue_h, Saturation_h, Lightness_h])

    # Threshold the HSV image to get only red colors
    mask = cv2.inRange(hsv, lower, upper)

    mask = cv2.erode(mask, None, iterations=2)
    mask = cv2.dilate(mask, None, iterations=2)

    # Bitwise-AND mask and original image
    res = cv2.bitwise_and(image, image, mask = mask)
    find_circle_in_tlight(res, color)


def find_circle_in_tlight(image, find_color):

    image = np.copy(image)

    output = image.copy()
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # detect circles in the image
    circles = cv2.HoughCircles(gray,cv2.HOUGH_GRADIENT,1,20, param1=50,param2=20,minRadius=10,maxRadius=0)
    
      
    # ensure at least some circles were found
    if circles is not None:
        # convert the (x, y) coordinates and radius of the circles to integers
        circles = np.round(circles[0, :]).astype("int")

        x,y,r = circles[0]

        cv2.circle(output, (x, y), r, GREEN, 4)
        cv2.rectangle(output, (x - 5, y - 5), (x + 5, y + 5), ORANGE, -1)
    
        print(find_color, "light detected")
        cv2.imshow(find_color, output)

    else:
        print (find_color, "not found")


def find_tlightcolor(image):
    
    filter_color(image, 'green')
    filter_color(image, 'yellow')
    filter_color(image, 'red')

def main():

    green_img = cv2.imread('green_light.png')
    yellow_img = cv2.imread('yellow_light.png')
    red_img = cv2.imread('red_light.png')
    
    find_tlightcolor(green_img)
    find_tlightcolor(yellow_img)
    find_tlightcolor(red_img)
    
    cv2.waitKey(1)

main()

