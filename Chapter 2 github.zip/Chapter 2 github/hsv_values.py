hue_red_l = 0
hue_red_h = 10
saturation_red_l = 30
saturation_red_h = 255
lightness_red_l = 48
lightness_red_h = 255

hue_yellow_l = 20
hue_yellow_h = 35
saturation_yellow_l = 100
saturation_yellow_h = 255
lightness_yellow_l = 50
lightness_yellow_h = 255

hue_green_l = 46
hue_green_h = 76
saturation_green_l = 86
saturation_green_h = 255
lightness_green_l = 50
lightness_green_h = 255
