import cv2
import numpy as np
import pyzbar.pyzbar as pyzbar

BLUE = (255,0,0)
GREEN = (0,255,0)
RED = (0,0,255)
 
cap = cv2.VideoCapture(0)
font = cv2.FONT_HERSHEY_PLAIN


def show_axis(obj, frame):

        #draw two axis to check for orientation
        p1 = obj.polygon[0]
        p2 = obj.polygon[1]

        p3 = obj.polygon[2]
        p4 = obj.polygon[3]

        # 'horizontal'
        cv2.line(frame, p1, p2, GREEN,2)
        # 'vertical'
        cv2.line(frame, p1, p4, RED, 2)

        return p1, p4
    

def show_direction(obj, frame, p1, p4):

        #identify top left corner and draw a circle in the center
        x = obj.rect.left + int(obj.rect.width/2)
        y = obj.rect.top + int(obj.rect.height/2)
        w = obj.rect.width
        radius = int(w/7)
        
        cv2.circle(frame, (x, y), radius, BLUE, 2)

        
        #calculate mid point along p1 and p2 axis

        xtip = p1[0]+ int((p4[0] - p1[0])/2)
        ytip = p1[1] +int((p4[1] - p1[1])/2)

        cv2.line(frame, (x,y), (xtip,ytip), BLUE,2)
 


        return x,y


def show_robotnames(obj, frame, x, y):

        #Last 8 characters only
        text = str(obj.data)
        text = text[-8:]

        #Text position with respect to center of object
        xtext = x - int(obj.rect.width/2)
        ytext = y + int(obj.rect.height*2/3)
        
        cv2.putText(frame, text, (xtext, ytext), font, 2, BLUE, 2)


def main():
 
    while True:

        ret, frame = cap.read()
    
        #Locate all QR codes
        decodedObjects = pyzbar.decode(frame)    

        #Iterate from decoded objects, display axis, direction and names
        for obj in decodedObjects:

            p1,p4 = show_axis(obj, frame)
           
            x,y = show_direction(obj, frame , p1, p4)
            show_robotnames(obj, frame, x, y)

     
        cv2.imshow("Robots positions", frame)
     
        key = cv2.waitKey(1)
        if key == 27:
            break

main()
