import cv2
import numpy as np
import pyzbar.pyzbar as pyzbar

BLUE = (255,0,0)
GREEN = (0,255,0)
RED = (0,0,255)
 
cap = cv2.VideoCapture(0)
font = cv2.FONT_HERSHEY_PLAIN


def show_axis(obj, frame):

        #draw two axis to check for orientation
        p1 = obj.polygon[0]
        p2 = obj.polygon[1]

        p3 = obj.polygon[2]
        p4 = obj.polygon[3]

        # 'horizontal'
        #cv2.line(frame, p1, p2, GREEN,2)
        # 'vertical'
        #cv2.line(frame, p1, p4, RED, 2)

        return p1, p2, p3, p4

def crop_image(frame,p1,p2,p3,p4):

        #crop image
        pts = np.array([[p1[0],p1[1]],[p2[0],p2[1]],[p3[0],p3[1]],[p4[0],p4[1]]])

        ## (1) Crop the bounding rect
        rect = cv2.boundingRect(pts)
        x,y,w,h = rect
        cropped = frame[y:y+h, x:x+w].copy()

        ## (2) make mask
        pts = pts - pts.min(axis=0)

        mask = np.zeros(cropped.shape[:2], np.uint8)
        cv2.drawContours(mask, [pts], -1, (255, 255, 255), -1, cv2.LINE_AA)
        #cv2.imshow("Mask",mask)

        ## (3) do bit-op
        dst = cv2.bitwise_and(cropped, cropped, mask=mask)
        #cv2.imshow("Dst", dst)

        return dst


def filter_redimage(cropped_image):

        #Identify red corner
        img_hsv=cv2.cvtColor(cropped_image, cv2.COLOR_BGR2HSV)

        # lower mask (0-10)
        lower_red = np.array([0,50,50])
        upper_red = np.array([10,255,255])
        mask0 = cv2.inRange(img_hsv, lower_red, upper_red)

        # upper mask (170-180)
        lower_red = np.array([170,50,50])
        upper_red = np.array([180,255,255])
        mask1 = cv2.inRange(img_hsv, lower_red, upper_red)

        # join my masks
        mask = mask0+mask1

        # set my output img to zero everywhere except my mask
        output_img = cropped_image.copy()
        output_img[np.where(mask==0)] = 0

        return mask, output_img


def find_contours(filtered_redimage):

        # Finding contours

        # create binary image
        gray = cv2.cvtColor(filtered_redimage, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (5, 5), 0)
        (t, binary) = cv2.threshold(blur, 20, 255, cv2.THRESH_BINARY)

        # find contours
        contours, hierarchy = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # draw contours over original image
        cv2.drawContours(filtered_redimage, contours, -1, (0, 0, 255), 5)

        try:

                M = cv2.moments(contours[0])
                cX = int(M["m10"] / M["m00"])
                cY = int(M["m01"] / M["m00"])                                
                print (cX,cY)                             

        except:
                pass

        return filtered_redimage, cX, cY
       

def show_direction(obj, frame, p1, p4):

        #identify top left corner and draw a circle in the center
        x = obj.rect.left + int(obj.rect.width/2)
        y = obj.rect.top + int(obj.rect.height/2)
        w = obj.rect.width
        radius = int(w/7)
        
        cv2.circle(frame, (x, y), radius, BLUE, 2)

        
        #calculate mid point along p1 and p2 axis

        xtip = p1[0]+ int((p4[0] - p1[0])/2)
        ytip = p1[1] +int((p4[1] - p1[1])/2)

        cv2.line(frame, (x,y), (xtip,ytip), BLUE,2)
 


        return x,y


def show_robotnames(obj, frame, x, y):

        #Last 8 characters only
        text = str(obj.data)
        text = text[-8:]

        #Text position with respect to center of object
        xtext = x - int(obj.rect.width/2)
        ytext = y + int(obj.rect.height*2/3)
        
        cv2.putText(frame, text, (xtext, ytext), font, 2, BLUE, 2)


def main():

        counter = 0
        
 
        while True:

                ret, frame = cap.read()

                            
                #Locate all QR codes
                decodedObjects = pyzbar.decode(frame)
                #find_contoursimage = None

                #Iterate from decoded objects, display axis, direction and names
                for obj in decodedObjects:

                        p1, p2, p3, p4 = show_axis(obj, frame)
                        cropped_image = crop_image(frame,p1,p2,p3,p4)
                        #cv2.imshow("cropped image", cropped_image)

                        try:
                                mask, filtered_redimage = filter_redimage(cropped_image)
                                #cv2.imshow("Red filter", filtered_redimage)

                                midX = p1[0] + int((p3[0] - p1[0])/2)
                                midY = p1[1] + int((p3[1] - p1[1])/2)  
        
                                find_contoursimage, cX, cY = find_contours(filtered_redimage)
                                
                                width = filtered_redimage.shape[0]
                                height = filtered_redimage.shape[1]

                                if ( cY / height < 0.7) and (cX/width > 0.5) :
                                        print("Top Right")
                                elif ( cY / height < 0.7) and (cX/width < 0.5) :
                                        print("Top Left")
                                elif ( cY / height > 0.7) and (cX/width < 0.5) :
                                        print("Bottom Left")
                                elif ( cY / height > 0.7) and (cX/width > 0.5) :
                                        print("Bottom Right")



                                #print(width,height,cX,cY)
                                cv2.circle(frame, (midX, midY), 10, GREEN, 2)

                                cv2.imshow('Detected red contours', find_contoursimage)
                                                        
                                x,y = show_direction(obj, frame , p1, p4)
                                show_robotnames(obj, frame, x, y)
                               
                        except:
                                pass

                        

                        

             
                cv2.imshow("Robots positions", frame)
                
             
                key = cv2.waitKey(1)
                if key == 27:
                    break

main()
