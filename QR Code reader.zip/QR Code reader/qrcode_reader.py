import cv2
import numpy as np
import pyzbar.pyzbar as pyzbar

BLUE = (255,0,0)
GREEN = (0,255,0)
RED = (0,0,255)
 
cap = cv2.VideoCapture(0)
font = cv2.FONT_HERSHEY_PLAIN
 
while True:

    ret, frame = cap.read()
 
    decodedObjects = pyzbar.decode(frame)    

    for obj in decodedObjects:
        
        #Show the QR code data
        cv2.putText(frame, str(obj.data), (50, 50), font, 2, BLUE, 3)

        #identify top left corner and draw a circle
        x = obj.rect.left
        y = obj.rect.top
        w = obj.rect.width
        radius = int(w/4)
        
        cv2.circle(frame, (x, y), radius, BLUE, 2)

        #draw two axis to check for orientation
        p1 = obj.polygon[0]
        p2 = obj.polygon[1]

        p3 = obj.polygon[2]
        p4 = obj.polygon[3]

        # 'horizontal'
        cv2.line(frame, p1, p2, GREEN,2)
        # 'vertical'
        cv2.line(frame, p1, p4, RED, 2)
 
    cv2.imshow("QR Code Display", frame)
 
    key = cv2.waitKey(1)
    if key == 27:
        break
